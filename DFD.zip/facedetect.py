# import cv2
# import mediapipe as mp
# import time

# cap = cv2.VideoCapture(0)
# pTime = 0

# mpDraw = mp.solutions.drawing_utils
# mpFaceMesh = mp.solutions.face_mesh
# faceMesh = mpFaceMesh.FaceMesh(max_num_faces=10)
# drawSpec = mpDraw.DrawingSpec(thickness=1, circle_radius=1)

# # Initialize an empty list to store landmarks
# landmarks_list = []

# # Set the maximum duration for execution (10 minutes)
# max_duration = 20  
# start_time = time.time()

# while True:
#     success, img = cap.read()
#     imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
#     results = faceMesh.process(imgRGB)
#     ih, iw, ic = img.shape
#     if results.multi_face_landmarks:
#         for faceLms in results.multi_face_landmarks:
#             mpDraw.draw_landmarks(img, faceLms, mpFaceMesh.FACEMESH_CONTOURS, drawSpec, drawSpec)
#             for id, lm in enumerate(faceLms.landmark):
#                 x, y = int(lm.x * iw), int(lm.y * ih)
#                 # Append the landmark coordinates to the list
#                 landmarks_list.append((x, y))

#     cTime = time.time()
#     fps = 1 / (cTime - pTime)
#     pTime = cTime
#     cv2.putText(img, f'FPS: {int(fps)}', (20, 70), cv2.FONT_HERSHEY_PLAIN,
#                 3, (255, 0, 0), 3)
#     cv2.imshow("Image", img)
#     cv2.waitKey(1)

#     # Check if the maximum duration has elapsed
#     if time.time() - start_time >= max_duration:
#         print("Execution stopped after 10 minutes.")
#         break
# print(landmarks_list)


import cv2
from mtcnn import MTCNN
import matplotlib.pyplot as plt
 
# Initialize MTCNN face detector
detector = MTCNN()
 
def detect_faces(image):
    # Detect faces in the image
    faces = detector.detect_faces(image)
   
    # Extract bounding boxes from the detected faces
    face_boxes = [face['box'] for face in faces]
   
    return face_boxes, faces
 
def draw_faces(image, faces):
    # Draw bounding boxes and keypoints on the image
    for face in faces:
        x, y, w, h = face['box']
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
 
        keypoints = face['keypoints']
        for point, coords in keypoints.items():
            cv2.circle(image, coords, 2, (0, 255, 0), 2)
 
def main(image_path):
    # Load the image
    image = cv2.imread(image_path)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Convert to RGB for MTCNN
 
    # Detect faces
    face_boxes, faces = detect_faces(image_rgb)
 
    # Draw faces
    draw_faces(image_rgb, faces)
 
    # Display the output image
    plt.figure(figsize=(10, 10))
    plt.imshow(image_rgb)
    plt.axis('off')
    plt.show()
 
# Run the main function with an image path
main(r'Images\friends2.jpg')