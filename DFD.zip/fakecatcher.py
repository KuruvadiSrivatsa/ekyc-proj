import cv2
import numpy as np
from scipy.signal import butter, filtfilt
import matplotlib.pyplot as plt
# Load the video
video_path = r'dfdc_train_part_07\dfdc_train_part_7\qhkwjzpuud.mp4'
cap = cv2.VideoCapture(video_path)

# Load the pre-trained face detector
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Define a function to extract frames and detect faces
def extract_frames_and_detect_faces(video_path):
    cap = cv2.VideoCapture(video_path)
    frames = []
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)
        for (x, y, w, h) in faces:
            roi_color = frame[y:y+h, x:x+w]
            frames.append(roi_color)
    cap.release()
    return frames

# Extract frames with detected faces
frames = extract_frames_and_detect_faces(video_path)

def extract_green_channel_signal(frames):
    signals = []
    for frame in frames:
        # Assuming the forehead region is the upper part of the face
        height, width, _ = frame.shape
        forehead_region = frame[:height//3, :]
        green_channel = forehead_region[:, :, 1]
        mean_green_value = np.mean(green_channel)
        signals.append(mean_green_value)
    return signals

# Extract the green channel signal
green_channel_signal = extract_green_channel_signal(frames)

def bandpass_filter(signal, lowcut, highcut, fs, order=5):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    y = filtfilt(b, a, signal)
    return y

# Define the parameters for the bandpass filter
fs = 30  # Sampling frequency (frame rate of the video)
lowcut = 0.8  # Lower bound of the heart rate frequency
highcut = 2.5  # Upper bound of the heart rate frequency

# Apply the bandpass filter to the green channel signal
filtered_signal = bandpass_filter(green_channel_signal, lowcut, highcut, fs)
def create_spatiotemporal_map(signal, width, height):
    spatiotemporal_map = np.zeros((height, width))
    signal_length = len(signal)
    for i in range(height):
        for j in range(width):
            if i < signal_length:
                spatiotemporal_map[i, j] = signal[i]
    return spatiotemporal_map

# Define the dimensions of the spatiotemporal map
map_height = len(filtered_signal)
map_width = 50  # Arbitrary width

# Create the spatiotemporal map
spatiotemporal_map = create_spatiotemporal_map(filtered_signal, map_width, map_height)

# Display the spatiotemporal map
plt.imshow(spatiotemporal_map, aspect='auto', cmap='hot')
plt.colorbar()
plt.title('Spatiotemporal Map')
plt.xlabel('Spatial Dimension')
plt.ylabel('Temporal Dimension')
plt.show()
