import cv2
import dlib
import os
import numpy as np
import matplotlib.pyplot as plt
from pyts.image import RecurrencePlot

# Extract frames from video for the first 15 seconds
def extract_frames(video_path, max_seconds=15):
    cap = cv2.VideoCapture(video_path)
    frames = []
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    max_frames = max_seconds * fps
    count = 0
    
    while cap.isOpened() and count < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)
        count += 1
    
    cap.release()
    return frames

# Detect faces in frames
detector = dlib.get_frontal_face_detector()

def detect_faces(frames):
    faces = []
    for frame in frames:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        detected_faces = detector(gray, 1)
        faces.append(detected_faces)
    return faces

# Extract PPG signals from detected faces
def extract_ppg_signals(frames, faces):
    ppg_signals = []
    for i, face_set in enumerate(faces):
        if len(face_set) > 0:
            face = face_set[0]  # Assuming one face per frame
            x, y, w, h = face.left(), face.top(), face.width(), face.height()
            face_region = frames[i][y:y+h, x:x+w]
            mean_color = np.mean(face_region, axis=(0, 1))  # Average color in the face region
            ppg_signals.append(mean_color)
    return np.array(ppg_signals)

# Convert PPG pulse signals to recurrence plot
def convert_to_recurrence_plot(ppg_signals):
    rp = RecurrencePlot()
    recurrence_plot = rp.fit_transform(ppg_signals.reshape(1, -1))
    return recurrence_plot[0]

# Main function to process each video
def process_video(video_path, output_dir):
    frames = extract_frames(video_path)
    print(f"Extracted {len(frames)} frames from {video_path}")
    
    faces = detect_faces(frames)
    print(f"Detected faces in {len(faces)} frames from {video_path}")
    
    ppg_signals = extract_ppg_signals(frames, faces)
    print(f"PPG signals shape for {video_path}: {ppg_signals.shape}")
    
    if ppg_signals.ndim == 2 and ppg_signals.shape[1] == 3:
        recurrence_plot = convert_to_recurrence_plot(ppg_signals[:, 0])  # Using one color channel (e.g., Red)
        
        plt.imshow(recurrence_plot, cmap='binary', origin='lower')
        plt.title(f'Recurrence Plot of PPG Pulse Signal - {os.path.basename(video_path)}')
        
        # Save the plot
        plot_path = os.path.join(output_dir, os.path.basename(video_path).replace('.mp4', '_recurrence_plot.png'))
        plt.savefig(plot_path)
        plt.close()
        
        print(f"Saved recurrence plot for {video_path} to {plot_path}")
    else:
        print(f"PPG signals for {video_path} are not in the expected shape.")

# Process a folder of videos
def process_videos_in_folder(folder_path, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for video_file in os.listdir(folder_path):
        if video_file.endswith('.mp4'):
            video_path = os.path.join(folder_path, video_file)
            process_video(video_path, output_dir)

# Run the process
video_folder_path = 'test_folder'
output_folder_path = 'test_plots'
process_videos_in_folder(video_folder_path, output_folder_path)
